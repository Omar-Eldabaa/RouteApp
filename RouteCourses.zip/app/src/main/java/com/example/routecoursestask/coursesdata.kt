package com.example.routecoursestask

import android.widget.Button

data class CoursesData (
    val id :Int? =null ,
    val courseName:String? = null,
    val image : Int? = null ,
    val courseContent: String?=null
        )
