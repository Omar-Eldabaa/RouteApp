package com.example.routecoursestask

interface onClickListener {
    fun onCourseClick( data : CoursesData )

}